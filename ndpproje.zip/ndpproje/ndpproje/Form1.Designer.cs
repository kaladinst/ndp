﻿namespace ndpProje
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ScheduleButton = new Button();
            CancelButton = new Button();
            nameText = new TextBox();
            surnameText = new TextBox();
            label1 = new Label();
            label2 = new Label();
            phoneText = new TextBox();
            label3 = new Label();
            label4 = new Label();
            serviceBox = new ComboBox();
            label5 = new Label();
            appointmentsDataGridView = new DataGridView();
            appointmentDatePicker = new DateTimePicker();
            DeleteButton = new Button();
            RearrangeButton = new Button();
            ((System.ComponentModel.ISupportInitialize)appointmentsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // ScheduleButton
            // 
            ScheduleButton.Location = new Point(55, 248);
            ScheduleButton.Name = "ScheduleButton";
            ScheduleButton.Size = new Size(75, 23);
            ScheduleButton.TabIndex = 0;
            ScheduleButton.Text = "Schedule";
            ScheduleButton.UseVisualStyleBackColor = true;
            ScheduleButton.Click += ScheduleButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.Location = new Point(190, 248);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(75, 23);
            CancelButton.TabIndex = 1;
            CancelButton.Text = "Cancel";
            CancelButton.UseVisualStyleBackColor = true;
            CancelButton.Click += CancelButton_Click;
            // 
            // nameText
            // 
            nameText.Location = new Point(43, 54);
            nameText.Name = "nameText";
            nameText.Size = new Size(100, 23);
            nameText.TabIndex = 2;
            // 
            // surnameText
            // 
            surnameText.Location = new Point(43, 97);
            surnameText.Name = "surnameText";
            surnameText.Size = new Size(100, 23);
            surnameText.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(76, 36);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 4;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(71, 80);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 5;
            label2.Text = "Surname";
            // 
            // phoneText
            // 
            phoneText.Location = new Point(43, 141);
            phoneText.Name = "phoneText";
            phoneText.Size = new Size(100, 23);
            phoneText.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(70, 123);
            label3.Name = "label3";
            label3.Size = new Size(41, 15);
            label3.TabIndex = 7;
            label3.Text = "Phone";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(215, 36);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 8;
            // 
            // serviceBox
            // 
            serviceBox.FormattingEnabled = true;
            serviceBox.Location = new Point(155, 54);
            serviceBox.Name = "serviceBox";
            serviceBox.Size = new Size(203, 23);
            serviceBox.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(232, 36);
            label5.Name = "label5";
            label5.Size = new Size(44, 15);
            label5.TabIndex = 10;
            label5.Text = "Service";
            // 
            // appointmentsDataGridView
            // 
            appointmentsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            appointmentsDataGridView.Location = new Point(319, 83);
            appointmentsDataGridView.Name = "appointmentsDataGridView";
            appointmentsDataGridView.Size = new Size(448, 355);
            appointmentsDataGridView.TabIndex = 11;
            // 
            // appointmentDatePicker
            // 
            appointmentDatePicker.Location = new Point(43, 192);
            appointmentDatePicker.Name = "appointmentDatePicker";
            appointmentDatePicker.Size = new Size(200, 23);
            appointmentDatePicker.TabIndex = 12;
            appointmentDatePicker.ValueChanged += appointmentDatePicker_ValueChanged;
            // 
            // DeleteButton
            // 
            DeleteButton.Location = new Point(55, 298);
            DeleteButton.Name = "DeleteButton";
            DeleteButton.Size = new Size(75, 23);
            DeleteButton.TabIndex = 13;
            DeleteButton.Text = "Delete";
            DeleteButton.UseVisualStyleBackColor = true;
            DeleteButton.Click += DeleteButton_Click;
            // 
            // RearrangeButton
            // 
            RearrangeButton.Location = new Point(190, 298);
            RearrangeButton.Name = "RearrangeButton";
            RearrangeButton.Size = new Size(75, 23);
            RearrangeButton.TabIndex = 14;
            RearrangeButton.Text = "Rearrange";
            RearrangeButton.UseVisualStyleBackColor = true;
            RearrangeButton.Click += RearrangeButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(RearrangeButton);
            Controls.Add(DeleteButton);
            Controls.Add(appointmentDatePicker);
            Controls.Add(appointmentsDataGridView);
            Controls.Add(label5);
            Controls.Add(serviceBox);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(phoneText);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(surnameText);
            Controls.Add(nameText);
            Controls.Add(CancelButton);
            Controls.Add(ScheduleButton);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)appointmentsDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button ScheduleButton;
        private Button CancelButton;
        private TextBox nameText;
        private TextBox surnameText;
        private Label label1;
        private Label label2;
        private TextBox phoneText;
        private Label label3;
        private Label label4;
        private ComboBox serviceBox;
        private Label label5;
        private DataGridView appointmentsDataGridView;
        private DateTimePicker appointmentDatePicker;
        private Button DeleteButton;
        private Button RearrangeButton;
    }
}
