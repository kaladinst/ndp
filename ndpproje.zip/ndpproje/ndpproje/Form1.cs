using System.IO;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Globalization;
using System.Linq;
using System.ComponentModel;

namespace ndpProje
{
    public partial class Form1 : Form
    {
        private Appointment appointment;
        private BindingList<Appointment> appointmentList = new BindingList<Appointment>();
        public class Person
        {
            public string Name { get; set; }
            public string Surname { get; set; }
            public string ContactInfo { get; set; }
        }
        public interface IAppointment
        {
            string Schedule();
            string Cancel();
        }
        public interface IAppointmentManager
        {
            string ScheduleAppointment(Appointment appointment);
            string ManageAppointment(Appointment appointment);
            string CancelAppointment(Appointment appointment);
        }

        public class Customer : Person
        {
            public override string ToString()
            {
                return Name;
            }
        }
        public class Employee : Person, IAppointmentManager
        {
            public string ScheduleAppointment(Appointment appointment)
            {
                return appointment.Schedule();
            }

            public string ManageAppointment(Appointment appointment)
            {
                return $"Appointment for {appointment.Customer.Name} with {appointment.Employee.Name} for {appointment.Service.Name} is managed.";
            }

            public string CancelAppointment(Appointment appointment)
            {
                return appointment.Cancel();
            }
            public override string ToString()
            {
                return Name;
            }
            public string DeleteAppointment(Appointment appointment, BindingList<Appointment> appointmentList)
            {
                if (appointmentList.Contains(appointment))
                {
                    appointmentList.Remove(appointment);
                    return $"Appointment for {appointment.Customer.Name} with {appointment.Employee.Name} for {appointment.Service.Name} is deleted.";
                }
                return "Appointment not found.";
            }
            public string RearrangeAppointment(Appointment appointment, DateTime newDate)
            {
                if (appointment.IsScheduled)
                {
                    appointment.Date = newDate;
                    return $"Appointment for {appointment.Customer.Name} with {appointment.Employee.Name} for {appointment.Service.Name} is rescheduled to {newDate}.";
                }
                return "Appointment is not scheduled.";
            }

        }
        public class Service
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
            public override string ToString()
            {
                return $"{Name} - ${Price}";
            }
        }
        public class Appointment : IAppointment
        {
            public Customer Customer { get; set; }
            public Service Service { get; set; }
            public Employee Employee { get; set; }
            public DateTime Date { get; set; }
            public string ContactInfo { get; set; }
            public bool IsScheduled { get; set; }
            public string Schedule()
            {
                if (IsScheduled)
                {
                    return "Appointment is already scheduled.";
                }
                IsScheduled = true;
                return $"Appointment for {Customer.Name} with {Employee.Name} for {Service.Name} is scheduled on {Date}.";
            }

            public string Cancel()
            {
                if (!IsScheduled)
                {
                    return "Appointment is not scheduled.";
                }
                IsScheduled = false;
                return $"Appointment for {Customer.Name} with {Employee.Name} for {Service.Name} is cancelled.";
            }
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void ScheduleButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameText.Text) || string.IsNullOrWhiteSpace(surnameText.Text))
            {
                MessageBox.Show("Name and surname cannot be empty.");
                return;
            }
            if (string.IsNullOrWhiteSpace(phoneText.Text) || phoneText.Text.Length != 10 || !phoneText.Text.All(char.IsDigit))
            {
                MessageBox.Show("Contact info must be a 10-digit number.");
                return;
            }
            if (serviceBox.SelectedItem == null || ((Service)serviceBox.SelectedItem).Price == 0)
            {
                MessageBox.Show("Please select a service.");
                return;
            }
            Employee employee = new Employee { Name = "Employee Name" };
            appointment = new Appointment
            {
                Customer = new Customer { Name = nameText.Text, Surname = surnameText.Text, ContactInfo = phoneText.Text },
                Service = serviceBox.SelectedItem as Service,
                Employee = employee,
                Date = appointmentDatePicker.Value,
                ContactInfo = phoneText.Text,
            };

            string message = employee.ScheduleAppointment(appointment);
            MessageBox.Show(message);

            // Set IsScheduled to true after scheduling the appointment
            appointment.IsScheduled = true;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "database.txt");
            string data = $"{appointment.Customer.Name}|{appointment.Customer.Surname}|{appointment.Customer.ContactInfo}|{appointment.Service.Name}|{appointment.Date}";
            File.AppendAllText(filePath, data + Environment.NewLine);
            appointmentList.Add(appointment);
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            string message = appointment.Cancel();
            MessageBox.Show(message);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Service> services = new List<Service>
    {
        new Service { Name = "Select a service...", Price = 0 },
        new Service { Name = "Children's Haircut", Price = 20 },
        new Service { Name = "Men's Haircut", Price = 25 },
        new Service { Name = "Women's Haircut", Price = 30 },
        new Service { Name = "Hair Coloring", Price = 80 },
        new Service { Name = "Hair Styling", Price = 50 },
        new Service { Name = "Deep Conditioning Treatment", Price = 60 },
        new Service { Name = "Perm", Price = 120 },
        new Service { Name = "Straightening", Price = 150 },
        new Service { Name = "Blowout", Price = 35 }
    };

            serviceBox.DataSource = services;
            serviceBox.DisplayMember = "Name";
            serviceBox.ValueMember = "Price";

            Dictionary<string, Service> serviceLookup = services.ToDictionary(s => s.Name, s => s);

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "database.txt");

            if (File.Exists(filePath))
            {
                string[] appointments = File.ReadAllLines(filePath);

                serviceBox.SelectedIndex = 0;
                foreach (string appointment in appointments)
                {
                    string[] details = appointment.Split('|');
                    Service service;
                    if (serviceLookup.TryGetValue(details[3], out service))
                    {
                        this.appointmentList.Add(new Appointment
                        {
                            Customer = new Customer { Name = details[0], Surname = details[1], ContactInfo = details[2] },
                            Service = service,
                            Date = DateTime.ParseExact(details[4], "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)
                        });
                    }
                }

                appointmentsDataGridView.DataSource = appointmentList;
                appointmentsDataGridView.Columns["ContactInfo"].Visible = true;
            }
        }

        private void appointmentDatePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (appointmentsDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("No appointment selected.");
                return;
            }

            Appointment selectedAppointment = appointmentsDataGridView.SelectedRows[0].DataBoundItem as Appointment;

            // Delete the appointment
            Employee employee = new Employee { Name = "Employee Name" };
            string message = employee.DeleteAppointment(selectedAppointment, appointmentList);
            MessageBox.Show(message);

            // Refresh the DataGridView
            appointmentsDataGridView.DataSource = null;
            appointmentsDataGridView.DataSource = appointmentList;
        }

        private void RearrangeButton_Click(object sender, EventArgs e)
        {
            if (appointmentsDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("No appointment selected.");
                return;
            }

            // Get the selected appointment
            Appointment selectedAppointment = appointmentsDataGridView.SelectedRows[0].DataBoundItem as Appointment;

            // Rearrange the appointment
            Employee employee = new Employee { Name = "Employee Name" };
            DateTime newDate = appointmentDatePicker.Value; // Get the new date from the date picker
            string message = employee.RearrangeAppointment(selectedAppointment, newDate);
            MessageBox.Show(message);
        }
    }
}