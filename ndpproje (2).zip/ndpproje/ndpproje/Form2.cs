﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ndpProje.Form1;

namespace ndpProje
{
    public partial class Form2 : Form
    {
        public bool IsEmployee { get; set; }
        private Form1 form1;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            this.FormClosed += Form2_FormClosed;
            EmployeeData.Employee = new Employee { Name = "Emir", Surname = "Duman", Password = "123456" };
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e) // or Form1_FormClosed
        {
            Form3 form3 = Application.OpenForms.OfType<Form3>().FirstOrDefault();
            if (form3 != null)
            {
                form3.Hide();
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string name = nameText.Text;
            string password = passwordText.Text;
            string surname = surnameText.Text;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "employees.txt");

            if (File.Exists(filePath))
            {
                string[] employees = File.ReadAllLines(filePath);

                foreach (string employee in employees)
                {
                    string[] details = employee.Split('|');
                    if (details.Length >= 3)
                    {
                        if (name == details[0] && surname == details[1] && password == details[2])
                        {
                            IsEmployee = true;

                            form1.Show();
                            this.Hide();

                            Form3 form3 = Application.OpenForms.OfType<Form3>().FirstOrDefault();
                            if (form3 != null)
                            {
                                form3.Hide();
                            }

                            return;
                        }
                    }
                }
            }

            MessageBox.Show("Invalid credentials.");
            nameText.Clear();
            passwordText.Clear();
            surnameText.Clear();
        }
        }
    }
