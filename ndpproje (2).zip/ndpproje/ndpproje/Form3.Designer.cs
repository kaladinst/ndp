﻿namespace ndpProje
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            EmployeeButton = new Button();
            CustomerButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(273, 135);
            label1.Name = "label1";
            label1.Size = new Size(204, 15);
            label1.TabIndex = 0;
            label1.Text = "Are you an employee or a customer?";
            // 
            // EmployeeButton
            // 
            EmployeeButton.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            EmployeeButton.Location = new Point(273, 168);
            EmployeeButton.Name = "EmployeeButton";
            EmployeeButton.Size = new Size(75, 23);
            EmployeeButton.TabIndex = 1;
            EmployeeButton.Text = "Employee";
            EmployeeButton.UseVisualStyleBackColor = true;
            EmployeeButton.Click += EmployeeButton_Click;
            // 
            // CustomerButton
            // 
            CustomerButton.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            CustomerButton.Location = new Point(402, 168);
            CustomerButton.Name = "CustomerButton";
            CustomerButton.Size = new Size(75, 23);
            CustomerButton.TabIndex = 2;
            CustomerButton.Text = "Customer";
            CustomerButton.UseVisualStyleBackColor = true;
            CustomerButton.Click += CustomerButton_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CustomerButton);
            Controls.Add(EmployeeButton);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button EmployeeButton;
        private Button CustomerButton;
    }
}