﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ndpProje.Form1;

namespace ndpProje
{
    public partial class Form3 : Form
    {
        public bool IsEmployee { get; private set; }
        private Form1 form1;
        public Form3(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            this.FormClosing += Form3_FormClosing;
        }
        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Prevent the application from exiting if there are other forms open
            if (Application.OpenForms.Count > 1 && !(sender is Form3))
            {
                e.Cancel = true;
            }
        }


        private void EmployeeButton_Click(object sender, EventArgs e)
        {
            IsEmployee = true;
            if (form1 != null)
            {
                form1.IsCustomer = false;
                form1.UpdateButtonStatus();

            }
            Form2 form2 = new Form2(form1);
            form2.ShowDialog();
            this.Hide();
            form1.Visible = true;
        }

        private void CustomerButton_Click(object sender, EventArgs e)
        {
            IsEmployee = false;
            if (form1 != null)
            {
                form1.IsCustomer = true;
                form1.UpdateButtonStatus();
            }
            this.Close();
            form1.Visible = true;
        }
    }
}
